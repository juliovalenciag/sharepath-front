type Search = { [k: string]: string | string[] | undefined };

const REGION_LABELS: Record<string, string> = {
  cdmx: "Ciudad de México",
  edomex: "Estado de México",
  hgo: "Hidalgo",
  mor: "Morelos",
  qro: "Querétaro",
};

function safeDate(v: string | string[] | undefined) {
  if (!v || Array.isArray(v)) return undefined;
  const d = new Date(v);
  return isNaN(d.getTime()) ? undefined : d;
}

// NOTA: en Next 15, searchParams es Promise.
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<Search>;
}) {
  const sp = await searchParams;

  const regionKey = (sp.region as string) ?? "";
  const region = REGION_LABELS[regionKey] ?? "(sin región)";

  const start = safeDate(sp.start);
  const end = safeDate(sp.end);

  return (
    <div style={{ padding: 24 }}>
      <h1 style={{ fontWeight: 700 }}>Constructor – Smoke Test</h1>
      <ul style={{ marginTop: 8, lineHeight: 1.8 }}>
        <li>
          <b>region:</b> {regionKey} → {region}
        </li>
        <li>
          <b>start:</b> {start?.toISOString() ?? "(no)"}
        </li>
        <li>
          <b>end:</b> {end?.toISOString() ?? "(no)"}
        </li>
      </ul>
    </div>
  );
}
