export default function ItinerariosLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <div>{children}</div>;
}
