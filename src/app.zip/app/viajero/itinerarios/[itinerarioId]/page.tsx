export default function Page({ params }: { params: { itineraryId: string } }) {
  return (
    <main className="p-6">
      <h1 className="text-xl font-semibold">Ver itinerario</h1>
      <p className="text-sm text-muted-foreground">ID: {params.itineraryId}</p>
    </main>
  );
}
